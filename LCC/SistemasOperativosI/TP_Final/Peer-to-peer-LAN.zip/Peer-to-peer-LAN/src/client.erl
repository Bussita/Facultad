-module(client).
-export([start/0, loop/2]).
-include("dbg/macros.hrl").
-include_lib("kernel/include/file.hrl").


%% Inicia la interfaz de línea de comandos del cliente
startCli() ->
  ?DEBUG_PRINT("[DBG ~p] Iniciando CLI. Linkeado a loop con pid ~p~n", [self(), server]),
  cliLoop().


%% Bucle principal de la interfaz CLI que lee y procesa comandos del usuario
cliLoop() ->
  io:format("~n!> "),
  case io:get_line("") of
    eof -> 
      io:format("[ERROR] EOF detectado en ~p~n.", [self()]),
      server ! stop,
      error;

    "stop\n" -> 
      ?DEBUG_PRINT("[DBG ~p] Enviando stop a ~p~n", [self(), server]),
      server ! stop,
      ok,
      exit(normal);
    
    Line ->
      ?DEBUG_PRINT("[DBG ~p] Interpretando linea: ~p~n", [self(), Line]),
      interpret(Line),
      ?DEBUG_PRINT("[DBG ~p] Esperando siguiente comando.~n", [self()]),
      receive
        continue -> ok;
        _ -> error
      end,

      cliLoop()
  end.


%% Interpreta y ejecuta los comandos ingresados por el usuario
interpret("getid\n") -> 
  ?DEBUG_PRINT("[DBG ~p] Enviado getid al pid ~p~n", [self(), server]),
  server ! getid;
interpret("listar\n") -> 
  ?DEBUG_PRINT("[DBG ~p] Enviando list al pid ~p~n", [self(), server]),
  server ! listSharedFiles;
interpret("listar_peers\n") ->
  ?DEBUG_PRINT("[DBG ~p] Enviando listar_peers al pid ~p~n", [self(), server]),
  server ! listPeers;
interpret(Line) ->
  case string:tokens(Line, " ") of
    ["encontrar", Name] ->
      CleanPattern = string:trim(Name),
      server ! {findFile, CleanPattern};

    ["buscar", Pattern] -> 
      CleanPattern = string:trim(Pattern),
      server ! {searchFile, CleanPattern};
    
    ["descargar", FileName, PeerId] ->
      CleanPeerId = string:trim(PeerId),
      server ! {downloadRequest, FileName, CleanPeerId};
    
    ["listar_mis_archivos\n"] ->
      ?DEBUG_PRINT("[DBG ~p] Enviando listar_mis_archivos al pid ~p~n", [self(), server]),
      server ! listSharedFiles;
    
    ["help\n"] ->
      io:format("Comandos disponibles:~n"),
      io:format(" - getid: Obtiene el ID del nodo.~n"),
      io:format(" - encontrar <nombre>: Busca el nombre de un archivo entre mis compartidos.~n"),
      io:format(" - listar/listar_mis_archivos: Lista los archivos compartidos en el nodo.~n"),            
      io:format(" - listar_peers: Lista los peers conocidos en la red.~n"),            
      io:format(" - buscar <patron>: Busca archivos en toda la red P2P.~n"),
      io:format(" - descargar <nombre> <peer_id>: Descarga un archivo de otro nodo.~n"),
      io:format(" - stop: Detiene el nodo.~n"),
      cli ! continue;
    
    _ ->
      io:format("Comando no reconocido. Usa 'help' para ver comandos disponibles.~n"),
      cli ! continue
  end.


%% Función principal que inicializa el nodo P2P y sus componentes
start() ->
  io:format("Bienvenido al sistema de descarga y envio de  archivos P2P del grupo BUSSANICH STEEMAN GIMENEZ SOSA (BSGS). ~n ----------------------------------------------------------------------- ~n"),
  io:format("[BSGS] Se te esta asignando un ID unico, porfavor espera un cacho. ~n ----------------------------------------------------------------------- ~n"),
  
  Ip = peers:getIp(),
  Id = peers:getId(Ip),
  io:format("[BSGS] ID unico asignado (~p), proba usar el comando help para ver que podes hacer. Que lo disfrutes crack!. ~n ----------------------------------------------------------------------- ~n",[Id]),
  
  link(whereis(udp_listener)),
  link(whereis(hello_broadcast)),
  case files:list(?SHARED_FOLDER_PATH) of 
    {error, _} -> 
      io:format("[ERROR] Error al listar el directorio compartido.~n"),
      error;
    
    {_, Files} ->
      Socket = peers:createSocket(),
      peers:register(), 
      PidAccept = spawn_link(fun() -> process_flag(trap_exit, true), acceptLoop(Socket, Id) end),

      ?DEBUG_PRINT("[DBG ~p] ~n- ID: ~p~n- IP: ~p~n- Socket para conexiones entrantes: ~p~n- Escucha en: ~p~n~n", [self(), Id, Ip, Socket, PidAccept]),
      
      register(server, spawn(fun() -> loop(Files, Id) end)),
      register(cli, self()),
      startCli()
  end.


%% Bucle principal del servidor que maneja mensajes y comandos del nodo
loop(Files, Id) ->
  receive
    stop ->
      io:format("Cerrando loop...~n"),
      ok;

    getid ->
      io:format("Id: ~p~n", [Id]),
      cli ! continue,
      loop(Files, Id);
    
    listSharedFiles ->
      io:format("Archivos compartidos:~n"),
      lists:foreach(
        fun(File) ->
          FilePath = filename:join(?SHARED_FOLDER_PATH, File),
          case file:read_file_info(FilePath) of
            {ok, Info} ->
              io:format(" - ~s (tamaño: ~p bytes)~n", [File, Info#file_info.size]);
            {error, _} ->
              io:format(" - ~s (no se pudo obtener tamaño)~n", [File])
          end
        end, Files),
      cli ! continue,
      loop(Files, Id);

    listPeers ->
      KnownPeers = peers:scanPeers(),
      NumberOfPeers = length(KnownPeers),
      io:format("Peers conocidos en la red (total: ~p):~n", [NumberOfPeers]),
      case KnownPeers of
        [] ->
          io:format(" - Ningún peer conocido aún~n");
        
        _ ->
          lists:foreach(
            fun({PeerId, Ip, Port, _Timestamp}) ->
              io:format(" - ~s en ~p:~p~n", [PeerId, Ip, Port])
            end, KnownPeers)
      end,
      
      cli ! continue,
      loop(Files, Id);

    {findFile, Name} ->
      io:format("Buscando archivo ~p localmente~n", [Name]),
      LocalMatches = lists:filter( % TODO Cambiar, esta funcion anda mal!
        fun(File) -> string:str(File, Name) > 0 end,
        Files
      ),
      case LocalMatches of
        [] ->
          io:format("No se encontró ~p en archivos locales~n", [Name]);
        
        Matches ->
          io:format("Archivos locales encontrados:~n"),
          lists:foreach(
            fun(File) ->
              io:format(" - ~s~n", [File])
            end, Matches)
      end,

      cli ! continue,
      loop(Files, Id);

    {searchFile, Pattern} -> 
      io:format("Iniciando búsqueda distribuida para patrón: ~p~n", [Pattern]),
      spawn(fun() -> search:distributedSearch(Pattern, Id) end),
      cli ! continue,
      loop(Files, Id);
    
    {downloadRequest, FileName, PeerId} ->
      io:format("Iniciando descarga de archivo ~p del peer ~p~n", [FileName, PeerId]),
      spawn(fun() -> download:downloadFileFromPeer(FileName, PeerId, Id) end),
      cli ! continue,
      loop(Files, Id);

    _ ->
      loop(Files, Id)
  end.


%% Acepta conexiones TCP entrantes de otros peers en la red
acceptLoop(ListenSock, MyID) ->
  case gen_tcp:accept(ListenSock) of
    {ok, Socket} ->
      ?DEBUG_PRINT("[DBG ~p] Nueva conexion ~p. Derivando a handler.~n", [self(), Socket]),
      spawn(fun() -> handlePeer(Socket, MyID) end),
      acceptLoop(ListenSock, MyID);
    {error, closed} ->
      ?DEBUG_PRINT("[DBG ~p] Socket cerrado. Saliendo del loop.~n", [self()]),
      ok;
    {error, timeout} ->
      acceptLoop(ListenSock, MyID);
    {error, Reason} ->
      ?DEBUG_PRINT("[DBG ~p] Error al aceptar conexión: ~p~n", [self(), Reason]),
      acceptLoop(ListenSock, MyID)
  end.


%% Maneja las conexiones entrantes de otros peers y procesa sus peticiones
handlePeer(Socket, MyID) ->
  ?DEBUG_PRINT("[DBG ~p] Handler de Socket ~p iniciado~n", [self(), Socket]),
  case gen_tcp:recv(Socket, 0, 10000) of
    {ok, Data} ->
      ?DEBUG_PRINT("[DBG ~p] Datos recibidos: ~p~n", [self(), Data]),
      Request = string:trim(binary_to_list(Data)),
      search:handleRequest(Socket, Request, MyID);
    {error, Reason} ->
      ?DEBUG_PRINT("[DBG ~p] Error recibiendo datos: ~p~n", [self(), Reason])
  end,
  gen_tcp:close(Socket).
