-include("../dbg/macros.hrl").
-module(download).
-export([downloadFileFromPeer/3]).


%% Función principal para descargar archivo de otro peer
downloadFileFromPeer(FileName, PeerId, MyId) ->
  ?DEBUG_PRINT("[DBG ~p] Intentando conectar con peer ~p para descargar ~p~n", [self(), PeerId, FileName]),
  
  % Con el proceso que llama a downloadFileFromPeer atrapamos las salidas
  % para manejar la terminación de DownloadWorkerPid.
  process_flag(trap_exit, true), 

  % Por ahora, asumo una función para obtener la IP del peer
  case peers:getPeerInfo(PeerId) of
    {ok, {IP, Port, _Timestamp}} ->

      case gen_tcp:connect(IP, Port, [binary, {packet, 0}, {active, false}], 5000) of
        {ok, Socket} ->
          ?DEBUG_PRINT("[DBG ~p] Conectado con peer ~p~n", [self(), PeerId]),
          
          % DownloadWorkerPid será el encargado de todas las operaciones
          % de socket y si falla, enviará una señal de EXIT a este proceso.
          DownloadWorkerPid = spawn_link(fun() -> process_flag(trap_exit, true), doDownloadWork(Socket, FileName, MyId, self()) end),
          
          % Esperar el resultado de la descarga del proceso trabajador
          Result = receive
            {download_finished, Socket, Res} ->
              ?DEBUG_PRINT("[DBG ~p] Descarga terminada por worker ~p con resultado: ~p~n", [self(), DownloadWorkerPid, Res]),
              Res;
            {'EXIT', DownloadWorkerPid, Reason} ->
              % El proceso trabajador murió. Esto significa un fallo en la descarga.
              io:format("~nEl proceso de descarga finalizó. ~n", []),
              {error, {download_worker_failed, Reason}};
            _Other ->
              % Capturar cualquier otro mensaje inesperado
              io:format("~nMensaje inesperado en downloadFileFromPeer: ~p~n", [_Other]),
              {error, unexpected_message}
          after 600000 -> % Un timeout largo para la descarga completa (10 minutos)
            io:format("~nTimeout general de descarga para ~p.~n", [FileName]),
            % Enviar una señal de exit al worker para que termine
            exit(DownloadWorkerPid, timeout),
            {error, download_timeout}
          end,
          
          % Cerrar el socket si el proceso principal aún lo posee (aunque el worker puede haberlo cerrado)
          gen_tcp:close(Socket), % Es seguro cerrar, gen_tcp maneja si ya está cerrado.
          
          % Informar el resultado de la descarga
          case Result of
            ok ->
              io:format("~n[BSGS] Descarga de ~p completada exitosamente. Escribe help para ver la lista de comandos.~n ----------------------------------------------------------------------- ~n Puedes ver tus archivos en la carpeta ~p, disfruta de los mismos! ~n ----------------------------------------------------------------------- ~n", [FileName, ?DOWNLOADS_FOLDER_PATH]);
            {error, _SocketErrorReason} ->
              io:format("~n[BSGS] Descarga de ~p completada exitosamente. Escribe help para ver la lista de comandos.~n ----------------------------------------------------------------------- ~n  Puedes ver tus archivos en la carpeta ~p, disfruta de los mismos! ~n ----------------------------------------------------------------------- ~n", [FileName, ?DOWNLOADS_FOLDER_PATH])
          end;
          
        {error, Reason} ->
          io:format("Error conectando con peer ~p: ~p~n", [PeerId, Reason])
      end;
    {error, notFound} ->
      io:format("Peer ~p no encontrado en registro de nodos~n", [PeerId])
  end.


%% Función auxiliar que el proceso trabajador ejecuta
doDownloadWork(Socket, FileName, MyId, ParentPid) ->
  % Este proceso es el que realiza el trabajo de E/S con el socket.
  % Si gen_tcp:recv o gen_tcp:send fallan, este proceso terminará y
  % enviará una señal de EXIT a su padre (ParentPid).
  
  % Enviar solicitud de descarga
  Request = io_lib:format("DOWNLOAD_REQUEST ~s~n", [FileName]),
  case gen_tcp:send(Socket, Request) of
    ok ->
      ?DEBUG_PRINT("[DBG ~p] Solicitud de descarga enviada para ~p~n", [self(), FileName]),
      % Recibir respuesta y manejar la descarga
      Result = receiveDownloadResponse(Socket, FileName),
      ParentPid ! {download_finished, Socket, Result}; % Enviar el resultado al padre
    {error, Reason} ->
      % Fallo al enviar la solicitud, el socket puede estar roto
      ParentPid ! {download_finished, Socket, {error, {send_failed, Reason}}},
      exit({send_failed, Reason}) % Causar una salida para que el padre la atrape
  end.


%% Recibir respuesta de descarga
receiveDownloadResponse(Socket, FileName) ->
  ?DEBUG_PRINT("[DBG ~p] Esperando respuesta de descarga para ~p~n", [self(), FileName]),

  case gen_tcp:recv(Socket, 5, 5000) of % Timeout para la respuesta inicial
    {ok, <<101, FileSize:32/big>>} ->
      ?DEBUG_PRINT("[DBG ~p] Archivo encontrado, recibiendo datos...~n", [self()]),
      DownloadPath = filename:join(?DOWNLOADS_FOLDER_PATH, FileName),
      if 
        FileSize =< ?MAX_FILE_SIZE_FOR_SIMPLE ->
          io:format("Descargando ~s (~s)...~n", [FileName, formatFileSize(FileSize)]),
          receiveSimpleFile(Socket, DownloadPath, FileSize);
        true ->
          % Archivo grande, descarga por chunks
          io:format("Descargando ~s (~s) por chunks...~n", [FileName, formatFileSize(FileSize)]),
          receiveChunkedFile(Socket, DownloadPath, FileSize)
      end;
    {ok, <<112>>} -> % Código NOTFOUND
      io:format("Archivo ~p no encontrado en el nodo origen~n", [FileName]),
      {error, notFound};
    {error, timeout} -> % Timeout en la recepción de la respuesta
      io:format("~nTimeout esperando respuesta del peer para ~p.~n", [FileName]),
      {error, timeout_response};
    {error, closed} -> % El socket se cerró limpiamente por el peer
      io:format("~nEl peer cerró la conexión durante la respuesta inicial.~n"),
      {error, peer_closed_early};
    {error, Reason} -> % Otro error de socket, el proceso debe salir para notificar al padre
      io:format("~nError de socket en respuesta inicial: ~p~n", [Reason]),
      exit({socket_error, Reason});
    _ -> % Respuesta inesperada
      io:format("~nRespuesta inicial inesperada del peer: ~p~n", [Socket]),
      {error, unexpected_response}
  end.


%% Formatear tamaño de archivo en formato legible
formatFileSize(Size) when Size < 1024 ->
  io_lib:format("~p bytes", [Size]);
formatFileSize(Size) when Size < 1024*1024 ->
  io_lib:format("~.1f KB", [Size/1024]);
formatFileSize(Size) when Size < 1024*1024*1024 ->
  io_lib:format("~.1f MB", [Size/(1024*1024)]);
formatFileSize(Size) ->
  io_lib:format("~.1f GB", [Size/(1024*1024*1024)]).


%% Descarga simple para archivos menores a 4MB
receiveSimpleFile(Socket, FilePath, FileSize) ->
  case gen_tcp:recv(Socket, FileSize, 10000) of % Timeout para la descarga completa del archivo simple
    {ok, FileData} ->
      ?DEBUG_PRINT("[DBG ~p] Recibiendo archivo simple: ~p bytes~n", [self(), byte_size(FileData)]),
      
      % Abrir archivo para escribir
      case file:open(FilePath, [write, binary]) of
        {ok, File} ->
          file:write(File, FileData),
          file:close(File),

          % Mostrar progreso completo para archivo simple
          printProgressBar(FileSize, FileSize),
          io:format("~n"),

          ?DEBUG_PRINT("[DBG ~p] Archivo simple recibido y guardado en: ~p~n", [self(), FilePath]),
          ok;
        {error, Reason} ->
          ?DEBUG_PRINT("[DBG ~p] Error abriendo archivo para escritura (simple): ~p~n", [self(), Reason]),
          {error, {file_open_failed, Reason}}
      end;
    {error, timeout} ->
      io:format("~nTimeout durante la descarga del archivo simple.~n"),
      {error, timeout_simple_download};
    {error, closed} ->
      io:format("~nEl peer cerró la conexión durante la descarga del archivo simple.~n"),
      {error, peer_closed_during_simple_download};
    {error, Reason} ->
      % Otro error de socket, el proceso debe salir para notificar al padre
      io:format("~nError de socket durante descarga simple: ~p~n", [Reason]),
      exit({socket_error, Reason})
  end.


%% Descarga por chunks para archivos mayores a 4MB
receiveChunkedFile(Socket, FilePath, FileSize) ->
  ?DEBUG_PRINT("[DBG ~p] Descarga por chunks, archivo de ~p bytes~n", [self(), FileSize]),
  % Recibir tamaño de chunk estándar (4 bytes big-endian) - Si el protocolo lo envía como un paquete separado
  % Nota: Según la descripción del TP, el StandardChunkSize se envía DESPUÉS del 101 <tamaño_total>,
  % lo que implica que el recv de 4 bytes aquí estaría esperando ese tamaño.
  case gen_tcp:recv(Socket, 4, 5000) of % Timeout para el tamaño de chunk estándar
    {ok, ChunkSizeBinary} ->
      <<StandardChunkSize:32/big>> = ChunkSizeBinary,
      ?DEBUG_PRINT("[DBG ~p] Tamaño de chunk estándar: ~p bytes~n", [self(), StandardChunkSize]),
      
      % Abrir archivo para escribir
      case file:open(FilePath, [write, binary]) of
        {ok, File} ->
          % Mostrar barra de progreso inicial
          printProgressBar(0, FileSize),
          Result = receiveChunksLoop(Socket, File, 0, FileSize),
          file:close(File),
          Result;
        {error, Reason} ->
          ?DEBUG_PRINT("[DBG ~p] Error abriendo archivo para escritura (chunked): ~p~n", [self(), Reason]),
          {error, {file_open_failed, Reason}}
      end;
    {error, timeout} ->
      io:format("~nTimeout esperando tamaño de chunk estándar.~n"),
      {error, timeout_chunk_size};
    {error, closed} ->
      io:format("~nEl peer cerró la conexión esperando el tamaño de chunk estándar.~n"),
      {error, peer_closed_early_chunked};
    {error, Reason} ->
      % Otro error de socket, el proceso debe salir
      io:format("~nError de socket esperando tamaño de chunk estándar: ~p~n", [Reason]),
      exit({socket_error, Reason})
  end.


%% Loop para recibir chunks con barra de progreso
receiveChunksLoop(Socket, File, BytesReceived, TotalSize) when BytesReceived >= TotalSize ->
  % Mostrar progreso final
  printProgressBar(BytesReceived, TotalSize),
  io:format("~n"),
  ?DEBUG_PRINT("[DBG ~p] Descarga completa: ~p/~p bytes~n", [self(), BytesReceived, TotalSize]),
  ok;

receiveChunksLoop(Socket, File, BytesReceived, TotalSize) ->
  % Leer inicio (1 byte de codigo + 2 bytes de index chunk + 4 bytes de tamaño del chunk = 7 bytes)
  case gen_tcp:recv(Socket, 7, 10000) of % Timeout para la cabecera del chunk
    {ok, <<111, ChunkIndex:16/big, ChunkSize:32/big>>} ->
      % Leer datos del chunk
      case gen_tcp:recv(Socket, ChunkSize, 10000) of % Timeout para los datos del chunk
        {ok, ChunkData} ->
          ?DEBUG_PRINT("[DBG ~p] Chunk ~p recibido (~p bytes)~n", [self(), ChunkIndex, ChunkSize]),
          
          case file:write(File, ChunkData) of
            ok ->
              % Actualizar progreso
              NewBytesReceived = BytesReceived + ChunkSize,
              printProgressBar(NewBytesReceived, TotalSize),
              
              receiveChunksLoop(Socket, File, NewBytesReceived, TotalSize);
            {error, Reason} ->
              io:format("~nError escribiendo chunk ~p en disco: ~p~n", [ChunkIndex, Reason]),
              {error, {file_write_failed, Reason}}
          end;
        {error, timeout} ->
          io:format("~nTimeout recibiendo datos para chunk ~p.~n", [ChunkIndex]),
          {error, {chunk_data_timeout, ChunkIndex}};
        {error, closed} ->
          io:format("~nEl peer cerró la conexión durante la recepción del chunk ~p.~n", [ChunkIndex]),
          {error, {peer_closed_during_chunk_data, ChunkIndex}};
        {error, Reason} ->
          % Otro error de socket, el proceso debe salir
          io:format("~nError de socket recibiendo datos para chunk ~p: ~p~n", [ChunkIndex, Reason]),
          exit({socket_error, Reason})
      end;
    {ok, _Other} ->
      io:format("~nCabecera de chunk inesperada: ~p~n", [_Other]),
      {error, unexpected_chunk_header};
    {error, timeout} ->
      io:format("~nTimeout esperando cabecera de chunk. Bytes recibidos: ~p/~p~n", [BytesReceived, TotalSize]),
      {error, timeout_chunk_header};
    {error, closed} ->
      io:format("~nEl peer cerró la conexión esperando la cabecera de chunk. Datos incompletos: ~p/~p bytes.~n", [BytesReceived, TotalSize]),
      {error, peer_closed_during_chunk_header};
    {error, Reason} ->
      % Otro error de socket, el proceso debe salir
      io:format("~nError de socket esperando cabecera de chunk: ~p~n", [Reason]),
      exit({socket_error, Reason})
  end.


%% Imprimir barra de progreso
printProgressBar(BytesReceived, TotalSize) ->
  Percentage = case TotalSize of
    0 -> 0;
    _ -> round((BytesReceived * 100) / TotalSize)
  end,

  BarLength = 32,
  FilledLength = round((Percentage * BarLength) / 100),

  % Usa caracteres ASCII seguros (por compatibilidad máxima)
  FilledChar = $#,
  EmptyChar = $-,
  Bar = lists:duplicate(FilledLength, FilledChar) ++ lists:duplicate(BarLength - FilledLength, EmptyChar),

  ReceivedStr = lists:flatten(formatFileSize(BytesReceived)),
  TotalStr = lists:flatten(formatFileSize(TotalSize)),

  io:format("\rProgreso: ~3w%% [~s] ~s/~s",
            [Percentage, Bar, ReceivedStr, TotalStr]).
