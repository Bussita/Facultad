-module(peers).
-export([scanPeers/0, getId/1, getIp/0, createSocket/0, register/0, requestName/1, getPeerInfo/1, processPeerRequest/2]).
-include("../dbg/macros.hrl").
-include_lib("kernel/include/file.hrl").


%% Obtiene la dirección IP local del nodo (excluyendo localhost)
getIp() ->
  case inet:getif() of 
    {ok, Ifs} ->
      FilterIp = [Ip || {Ip, _, _} <- Ifs, Ip =/= {127,0,0,1}],
      case FilterIp of
        [_FirstIp, SecondIp | _] -> SecondIp;
        [FirstIp | _] -> FirstIp;
        [] -> {127,0,0,1} % Fallback a localhost si no hay otras IPs
      end;
    _X -> 
      io:format("Error al obtener el IP~n"),
      {127,0,0,1}
  end.


%% Obtiene un ID único para el nodo verificando disponibilidad en la red
getId(Ip) ->
  ?DEBUG_PRINT("[DBG] Iniciando proceso de obtención de ID con IP: ~p~n", [Ip]),
  case gen_udp:open(
    ?UDP_PORT, 
    [
      binary,
      {active, false}, 
      {reuseaddr, true}, 
      {broadcast, true}
    ]) of
    {ok, Socket} ->
      ?DEBUG_PRINT("[DBG] Socket UDP abierto correctamente en puerto ~p~n", [?UDP_PORT]),
      Id = requestName(Socket),
      ?DEBUG_PRINT("[DBG] Nombre asignado: ~p~n", [Id]),
      startUdpCommunication(Socket, Id, Ip),
      Id;

    {error, eaddrinuse} ->
      ?DEBUG_PRINT("[DBG] Puerto ~p en uso, intentando con socket cliente~n", [?UDP_PORT]),
      % Si el puerto está en uso, usar un socket cliente que se conecte al puerto principal
      case gen_udp:open(0, [binary, {active, false}, {reuseaddr, true}, {broadcast, true}]) of
        {ok, ClientSocket} ->
          Id = requestName(ClientSocket),
          ?DEBUG_PRINT("[DBG] Nombre asignado (cliente): ~p~n", [Id]),
          startUdpCommunication(ClientSocket, Id, Ip),
          Id;

        {error, Reason} ->
          ?DEBUG_PRINT("[ERROR] No se pudo abrir socket cliente: ~p~n", [Reason]),
          timer:sleep(1000),
          getId(Ip)
      end;

    {error, Reason} ->
      ?DEBUG_PRINT("[ERROR] No se pudo abrir el socket UDP: ~p~n", [Reason]),
      timer:sleep(1000),
      getId(Ip)
  end.


%% Inicializa la comunicación UDP después de obtener un ID válido
startUdpCommunication(Socket, Id, Ip) ->
  % Iniciar el listener UDP 
  ListenerPid = spawn(fun() -> process_flag(trap_exit, true), startUdpListener(Socket, Id) end),
  ?DEBUG_PRINT("[DBG] Listener UDP iniciado con PID: ~p~n", [ListenerPid]),
  register(udp_listener, ListenerPid),
  register(hello_broadcast, spawn(fun() -> process_flag(trap_exit, true), helloBroadcastLoop(Id, Socket) end)),
  ?DEBUG_PRINT("[DBG] Broadcaster iniciado con PID. ~n", []).


%% Genera un nombre alfanumérico aleatorio de 4 caracteres
generateRandomName() ->
  lists:flatten([lists:nth(rand:uniform(62), "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789") || _ <- lists:seq(1, 4)]).


%% Solicita un nombre único en la red usando protocolo de consenso
requestName(Socket) ->
  ProposedId = generateRandomName(),
  ?DEBUG_PRINT("[DBG] Solicitando nombre: ~p~n", [ProposedId]),
  
  % Enviar solicitud de nombre a la red
  Message = list_to_binary("NAME_REQUEST " ++ ProposedId ++ "\n"),
  BroadcastAddr = {255,255,255,255},
  gen_udp:send(Socket, BroadcastAddr, ?UDP_PORT, Message),
  
  % Esperar respuestas por 2 segundos usando socket pasivo
  case waitForNameResponsesPassive(Socket, ProposedId, 10000) of
    ok -> 
      ?DEBUG_PRINT("[DBG] Nombre ~p aceptado~n", [ProposedId]),
      ProposedId;
    
    conflict ->
      ?DEBUG_PRINT("[DBG] Conflicto con nombre ~p, reintentando~n", [ProposedId]),
      Rand = 2000 +  rand:uniform(8000),
      timer:sleep(Rand), % Esperar un tiempo aleatorio entre 2 y 10 segundos
      requestName(Socket)
  end.


%% Espera respuestas de conflicto de nombre durante el timeout especificado
waitForNameResponsesPassive(Socket, ProposedId, Timeout) ->
  StartTime = erlang:system_time(millisecond),
  waitForNameResponsesPassiveLoop(Socket, ProposedId, StartTime, Timeout).


%% Bucle interno para esperar respuestas de conflicto de nombre
waitForNameResponsesPassiveLoop(Socket, ProposedId, StartTime, Timeout) ->
  CurrentTime = erlang:system_time(millisecond),
  Elapsed = CurrentTime - StartTime,

  if Elapsed >= Timeout ->
    ok;

  true ->
    RemainingTime = Timeout - Elapsed,
    case gen_udp:recv(Socket, 0, RemainingTime) of %% minimo tiempo en milisegundos que sean significativos
      {ok, {Ip, Port, Data}} ->
        case binary_to_list(Data) of
          "INVALID_NAME " ++ ConflictId ->
            ?DEBUG_PRINT("[DBG] Me llego: ~p de ~p:~p a la hora ~p ~n", [Data, Ip, Port, erlang:system_time(second)]),
            CleanConflictId = string:strip(ConflictId, right, $\n),
            if 
              CleanConflictId == ProposedId -> 
                ?DEBUG_PRINT("[DBG] El nodo ~p:~p tiene mi mismo id (~p). Conflicto~n", [Ip, Port, CleanConflictId]),
                conflict;
              true -> waitForNameResponsesPassiveLoop(Socket, ProposedId, StartTime, Timeout)
            end;
          
          "NAME_REQUEST " ++ RequestedId -> 
            CleanRequestedId = string:strip(RequestedId, right, $\n),
            ?DEBUG_PRINT("[DBG] NAME_REQUEST ~p recibido de ~p~n", [CleanRequestedId, Ip]),
            MyIp = getIp(),
            if 
              Ip == MyIp -> 
                % Es mi propio mensaje, ignorar
                waitForNameResponsesPassiveLoop(Socket, ProposedId, StartTime, Timeout);
              CleanRequestedId == ProposedId -> 
                % Otro nodo quiere mi ID, enviar conflicto
                Response = "INVALID_NAME " ++ RequestedId ++ "\n",
                gen_udp:send(Socket, Ip, Port, list_to_binary(Response)),
                waitForNameResponsesPassiveLoop(Socket, ProposedId, StartTime, Timeout);
              true -> 
                waitForNameResponsesPassiveLoop(Socket, ProposedId, StartTime, Timeout)
            end;
          
          _ ->
            ?DEBUG_PRINT("[DBG] Encontre otra cosa: ~p ~n", [Data]),
            waitForNameResponsesPassiveLoop(Socket, ProposedId, StartTime, Timeout)
        end;
      
      {error, timeout} ->
        ?DEBUG_PRINT("[DBG] Error timeout. Terminando espera de respuestas~n", []),
        ok;
      
      _ ->
        ?DEBUG_PRINT("[DBG] Mensaje desconocido en recv~n", []),
        waitForNameResponsesPassiveLoop(Socket, ProposedId, StartTime, Timeout)
    end
  end.


%% Crea un socket TCP para escuchar conexiones entrantes de otros peers
createSocket() ->
  case gen_tcp:listen(?TCP_PORT, [binary, {packet, 0}, {active, false}, {reuseaddr, true}]) of 
    {ok, Socket} -> 
      Socket;
    
    {error, Reason} -> 
      io:format("[ERROR] Creacion del socket: ~p~n", [Reason]),
      error
  end.


%% Inicializa la tabla ETS de peers conocidos (vacia)
register() ->
  % Crear tabla ETS para almacenar peers conocidos
  case ets:info(knownPeers) of
    undefined ->
      ets:new(knownPeers, [named_table, public, set]),
      ?DEBUG_PRINT("[DBG] Tabla de peers creada~n", []);
    
    _ ->
      ?DEBUG_PRINT("[DBG] Tabla de peers ya existe~n", [])
  end.


%% Inicia el listener UDP para recibir mensajes HELLO y NAME_REQUEST
startUdpListener(Socket, Id) ->
  ?DEBUG_PRINT("[DBG ~p] Iniciando UDP listener pasivo con ID: ~p~n", [self(), Id]),
  udpListenLoopPassive(Socket, Id).


%% Bucle principal del listener UDP que procesa mensajes entrantes
udpListenLoopPassive(Socket, Id) ->
  case gen_udp:recv(Socket, 0) of 
    {ok, {Ip, Port, Data}} ->
      DataStr = binary_to_list(Data),
      ?DEBUG_PRINT("[DBG ~p] UDP recibido de ~p:~p - ~p~n", [self(), Ip, Port, DataStr]),
      spawn(fun() -> processUdpMessage(Socket, Id, Ip, DataStr) end),
      udpListenLoopPassive(Socket, Id);
    
    {error, closed} -> 
      ?DEBUG_PRINT("[DBG ~p] Se cerro el socket UDP. Terminando...~n", [self()]),
      closedSocket;

    {error, Reason} ->
      ?DEBUG_PRINT("[DBG ~p] Error en UDP recv: ~p~n", [self(), Reason]),
      udpListenLoopPassive(Socket, Id)
  end.


%% Procesa mensajes UDP recibidos (HELLO, NAME_REQUEST, INVALID_NAME)
processUdpMessage(Socket, Id, Ip, Message) ->
  MyIp = getIp(),
  case string:tokens(Message, " \n") of
    ["HELLO", PeerId, TcpPort] ->
      ?DEBUG_PRINT("[DBG] HELLO recibido de ~p en ~p:~p (Mi IP: ~p, Mi ID: ~p)~n", [PeerId, Ip, TcpPort, MyIp, Id]),
      % Filtrar mis propios mensajes por ID y por IP
      if 
        PeerId == Id ->
          ?DEBUG_PRINT("[DBG] Ignorando mi propio HELLO (mismo ID)~n", []);
        true -> 
          ?DEBUG_PRINT("[DBG] Procesando HELLO válido de ~p~n", [PeerId]),
          Now = erlang:system_time(second),
          updatePeerList(PeerId, {Ip, list_to_integer(TcpPort), Now})
      end;
    
    ["NAME_REQUEST", RequestedId] ->
      ?DEBUG_PRINT("[DBG] NAME_REQUEST recibido para ~p (mi ID: ~p, desde IP: ~p, mi IP: ~p)~n", [RequestedId, Id, Ip, MyIp]),
      % Solo responder si no es mi propia solicitud
      if 
        Id == RequestedId ->
          Response = "INVALID_NAME " ++ RequestedId ++ "\n",
          gen_udp:send(Socket, Ip, ?UDP_PORT, list_to_binary(Response)), 
          ?DEBUG_PRINT("[DBG] Enviando INVALID_NAME para ~p (conflicto con mi ID) A LA HORA ~p ~n", [RequestedId, erlang:system_time(second)]);
        true ->
          notConflicting
      end;
    
    ["INVALID_NAME", ConflictId] ->
      ?DEBUG_PRINT("[DBG] INVALID_NAME recibido para ~p A LA HORA ~p ~n", [ConflictId, erlang:system_time(second)]);
        
    _ ->
      ?DEBUG_PRINT("[DBG] Mensaje UDP no reconocido: ~p~n", [Message])
  end.


%% Actualiza la tabla ETS con información de un peer conocido
updatePeerList(PeerId, {Ip, Port, Now}) ->
  case ets:info(knownPeers) of
    undefined ->
      ets:new(knownPeers, [named_table, public, set]);
    
    _ -> ok
  end,
  ets:insert(knownPeers, {PeerId, Ip, Port, Now}),
  ?DEBUG_PRINT("[DBG] Peer actualizado: ~p -> ~p:~p en ~p~n", [PeerId, Ip, Port, Now]).


%% Escanea y retorna la lista de peers conocidos activos
scanPeers() -> getAll().


%% Obtiene todos los peers de la tabla ETS, eliminando los expirados
getAll() ->
  Now = erlang:system_time(second),
  Entries = ets:tab2list(knownPeers),
  ?DEBUG_PRINT("[DBG] Tabla de nodos conocidos entera: ~p~n", [Entries]),
  
  % Eliminar los expirados
  lists:foreach(
    fun({PeerId, _Ip, _Port, Timestamp}) ->
      ?DEBUG_PRINT("PeerId: ~p Timestamp: ~p Tiempo pasado: ~p~n", [PeerId, Timestamp, Now - Timestamp]),
      case Now - Timestamp > 45 of   %Borramos los nodos cuyo ultimo HELLo recibido exede el tiempo propuesto (45 segundos).
        true -> ets:delete(knownPeers, PeerId);
        false -> ok
      end
    end,
    Entries
  ),
  % Obtener lista actualizada
  ets:tab2list(knownPeers).


%% Bucle de broadcast periódico de mensajes HELLO a la red
helloBroadcastLoop(Id, Socket) ->
  Rand = 15000 + rand:uniform(5000), % Tiempo aleatorio entre 15 y 20 segundos
  receive 
    {'EXIT', From, Reason} ->
      ?DEBUG_PRINT("[DBG ~p] Proceso linkeado ~p murió: ~p. Terminando HELLO~n", [self(), From, Reason]),
      ok
  after Rand ->
    sendHelloBroadcast(Id, Socket),
    helloBroadcastLoop(Id, Socket)
  end.


%% Envía un mensaje HELLO broadcast a la red usando socket temporal
sendHelloBroadcast(Id, TempSocket) ->
      Message = list_to_binary("HELLO " ++ Id ++ " " ++ integer_to_list(?TCP_PORT) ++ "\n"),
      BroadcastAddr = {255,255,255,255},
      case gen_udp:send(TempSocket, BroadcastAddr, ?UDP_PORT, Message) of
        ok ->
          ?DEBUG_PRINT("[DBG] HELLO broadcast enviado para ~p~n", [Id]);
        
        {error, Reason} ->
          ?DEBUG_PRINT("[DBG] Error enviando HELLO broadcast: ~p~n", [Reason])
      end.
    
%% Obtiene información de un peer específico por su ID
getPeerInfo(PeerId) ->
  case ets:lookup(knownPeers, PeerId) of
    [{PeerId, Ip, Port, Timestamp}] ->
      {ok, {Ip, Port, Timestamp}};
    
    [] ->
      ?DEBUG_PRINT("[DBG] Peer ~p no encontrado~n", [PeerId]),
      {error, notFound}
  end.


%% Procesa solicitudes entrantes de otros peers (descarga y búsqueda)
processPeerRequest(Socket, Request) ->
  case string:tokens(Request, " \n") of
    ["DOWNLOAD_REQUEST", FileName] ->
      ?DEBUG_PRINT("[DBG ~p] Solicitud de descarga para archivo: ~p~n", [self(), FileName]),
      send:handleDownloadRequest(Socket, FileName);
    
    _ ->
      ?DEBUG_PRINT("[DBG ~p] Solicitud no reconocida: ~p~n", [self(), Request]),
      gen_tcp:send(Socket, <<112>>) % Enviar NOTFOUND por defecto
  end.
