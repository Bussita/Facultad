-module(search).
-include("../dbg/macros.hrl").
-include_lib("kernel/include/file.hrl").
-export([distributedSearch/2, handleRequest/3, searchCoordinator/3, displaySearchResults/2, searchPeer/6, getResultByIndex/2, enumerateResults/3]).


%% Inicia una búsqueda distribuida enviando peticiones a todos los peers conocidos
distributedSearch(Pattern, MyId) ->
  KnownPeers = peers:scanPeers(),
  ?DEBUG_PRINT("[DBG] Iniciando búsqueda distribuida a ~p peers~n", [length(KnownPeers)]),
  
  case KnownPeers of
    [] ->
      io:format("No hay otros peers en la red para buscar~n");
    _ ->
      % Crear proceso coordinador para recopilar resultados
      CoordinatorPid = spawn(fun() -> searchCoordinator(Pattern, length(KnownPeers), []) end),
      
      % Enviar búsquedas en paralelo
      lists:foreach(
        fun({PeerId, IP, Port, _Tiemestamp}) ->
          spawn(fun() -> searchPeer(PeerId, IP, Port, Pattern, MyId, CoordinatorPid) end)
        end,
        KnownPeers
      )
  end.


%% Coordina la recopilación de resultados de búsqueda de múltiples peers
searchCoordinator(Pattern, ExpectedResponses, Results) ->
  ?DEBUG_PRINT("[DBG] Coordinador iniciado para patron ~p~n", [Pattern]),
  receive
    {search_result, PeerId, Files} ->
      ?DEBUG_PRINT("[DBG] Llego el resultado de ~p: ~p~n", [PeerId, Files]),
      NewResults = [{PeerId, Files} | Results],
      NewExpected = ExpectedResponses - 1,
      if
        NewExpected =< 0 ->
          displaySearchResults(Pattern, NewResults);
        true ->
          searchCoordinator(Pattern, NewExpected, NewResults)
      end;
    {search_timeout, PeerId} ->
      ?DEBUG_PRINT("[DBG] Timeout en búsqueda a peer ~p~n", [PeerId]),
      NewExpected = ExpectedResponses - 1,
      if
        NewExpected =< 0 ->
          displaySearchResults(Pattern, Results);
        true ->
          searchCoordinator(Pattern, NewExpected, Results)
      end
  after 10000 -> % Timeout de 10 segundos
    displaySearchResults(Pattern, Results)
  end.


%% Muestra los resultados de búsqueda y permite al usuario descargar archivos
displaySearchResults(Pattern, Results) ->
  io:format("~nResultados de búsqueda para patrón '~s':~n", [Pattern]),
  case Results of
    [] ->
      io:format("No se encontraron archivos~n");
    _ ->
      enumerateResults(Results, 1, []),
      io:format("¿Deseas descargar alguno? (Y/n): "),
      case io:get_line("") of
        "Y\n" ->
          io:format("Ingresa el número del archivo a descargar: "),
          case io:get_line("") of
            Input ->
              case catch list_to_integer(string:trim(Input)) of
                N when is_integer(N) ->
                  case getResultByIndex(N, Results) of
                    {ok, {PeerId, FileName}} ->
                      server ! {downloadRequest, FileName, PeerId};
                    error ->
                      io:format("Número inválido~n")
                  end;
                _ -> io:format("Entrada inválida~n")
              end;
            _ -> ok
          end;
        _ ->
          io:format("No se descargará ningún archivo. Volviendo al menú...~n!> ")
      end
  end,
  io:format("~n").


%% Enumera y muestra los resultados de búsqueda con índices numéricos
enumerateResults([], _, Acc) ->
  put(search_map, lists:reverse(Acc));
enumerateResults([{PeerId, Files} | T], Index, Acc) ->
  FilteredFiles = lists:filter(fun({F, _}) -> F =/= "NO_MATCH" end, Files),
  case FilteredFiles of
    [] -> enumerateResults(T, Index, Acc);
    _ ->
      io:format("~nPeer ~s:~n", [PeerId]),
      NewAcc = lists:foldl(
        fun({FileName, Size}, {Idx, AccInner}) ->
          io:format(" - ~s (~p bytes) (~p)~n", [FileName, Size, Idx]),
          {Idx + 1, [{Idx, {PeerId, FileName}} | AccInner]}
        end,
        {Index, Acc},
        FilteredFiles
      ),
      {NextIndex, FinalAcc} = NewAcc,
      enumerateResults(T, NextIndex, FinalAcc)
  end.


%% Obtiene un resultado específico por su índice numérico
getResultByIndex(N, _) ->
  case lists:keyfind(N, 1, get(search_map)) of
    {_, {PeerId, FileName}} -> {ok, {PeerId, FileName}};
    false -> error
  end.


%% Realiza búsqueda en un peer específico conectándose vía TCP
searchPeer(PeerId, IP, Port, Pattern, MyId, CoordinatorPid) ->
  case gen_tcp:connect(IP, Port, [binary, {packet, 0}, {active, false}], 5000) of
    {ok, Socket} ->
      Request = "SEARCH_REQUEST " ++ MyId ++ " " ++ Pattern,
      gen_tcp:send(Socket, list_to_binary(Request)),
      
      % Recopilar respuestas
      Now = erlang:system_time(millisecond),
      Files = collectSearchResponses(Socket, [], Now, 8000),
      gen_tcp:close(Socket),
      
      CoordinatorPid ! {search_result, PeerId, Files};
    {error, Reason} ->
      ?DEBUG_PRINT("[DBG] Error conectando a ~p:~p - ~p~n", [IP, Port, Reason]),
      CoordinatorPid ! {search_timeout, PeerId}
  end.


%% Maneja diferentes tipos de peticiones entrantes (principalmente SEARCH_REQUEST)
handleRequest(Socket, Request, MyID) ->
  case string:tokens(Request, " ") of
    ["SEARCH_REQUEST", RequesterId, Pattern] ->
      ?DEBUG_PRINT("[DBG ~p] Procesando SEARCH_REQUEST de ~p para patrón: ~p~n", 
                  [self(), RequesterId, Pattern]),
      handleSearchRequest(Socket, MyID, Pattern);
    _ ->
      % Para otros tipos de requests, usar la función original
      peers:processPeerRequest(Socket, Request)
  end.


%% Procesa peticiones de búsqueda de otros peers y busca en archivos locales
handleSearchRequest(Socket, MyID, Pattern) ->
  % Obtener la lista actual de archivos compartidos
  case files:list(?SHARED_FOLDER_PATH) of
    {error, _} ->
      % Si hay error listando archivos, enviar respuesta vacía
      sendSearchResponse(Socket, MyID, Pattern, -1);
    {_, Files} ->
      % Buscar archivos que coincidan con el patrón
      MatchingFiles = files:searchLocalFiles(Files, Pattern),
      sendSearchResponses(Socket, MyID, MatchingFiles)
  end.


sendSearchResponses(_Socket, _MyID, []) -> ok;
sendSearchResponses(Socket, MyID, [{notFound, _, _} | Rest]) ->
  sendSearchResponse(Socket, MyID, "NO_MATCH", -1),
  sendSearchResponses(Socket, MyID, Rest);

sendSearchResponses(Socket, MyID, [{found, FileName, Size} | Rest]) ->
  sendSearchResponse(Socket, MyID, FileName, Size),
  sendSearchResponses(Socket, MyID, Rest).


%% Envía una respuesta individual de búsqueda al peer solicitante
sendSearchResponse(Socket, MyID, FileName, Size) ->
  Response = io_lib:format("SEARCH_RESPONSE ~s ~s ~p~n", [MyID, FileName, Size]),
  case gen_tcp:send(Socket, list_to_binary(Response)) of
    ok ->
      ?DEBUG_PRINT("[DBG ~p] Enviada respuesta: ~s~n", [self(), Response]);
    {error, Reason} ->
      ?DEBUG_PRINT("[DBG ~p] Error enviando respuesta: ~p~n", [self(), Reason])
  end.


%% Recopila respuestas de búsqueda de un peer conectado vía TCP
collectSearchResponses(Socket, Acc, StartTime, Timeout) ->
  Now = erlang:system_time(millisecond),
  Elapsed = Now - StartTime,
  if 
    Elapsed >= Timeout -> Acc;
    true ->
      Remaining = Timeout - Elapsed,
      case gen_tcp:recv(Socket, 0, Remaining) of
        {ok, Data} ->
          Response = string:trim(binary_to_list(Data)),
          case parseSearchResponse(Response) of
            {ok, FileName, Size} when Size >= 0 ->
              % Archivo encontrado, crear nueva lista acumulada
              NewAcc = Acc ++ [{FileName, Size}],
              collectSearchResponses(Socket, NewAcc, StartTime, Timeout);
            {ok, "NO_MATCH", -1} ->
              collectSearchResponses(Socket, Acc, StartTime, Timeout);
            {ok, _, -1} ->
              collectSearchResponses(Socket, Acc, StartTime, Timeout);
            {error, invalid_size} ->
              collectSearchResponses(Socket, Acc, StartTime, Timeout);
            {error, invalid_format} ->
              ?DEBUG_PRINT("[DBG] Probando parsearlo como varias respuestas en un solo mensaje TCP...~n", []),
              ResponseSeparated = string:tokens(Response, "\n"),
              Res = parseSearchResponses(ResponseSeparated, Acc),
              collectSearchResponses(Socket, Res, StartTime, Timeout)
          end;
        {error, timeout} ->
          Acc;
        {error, _} ->
          Acc
      end
  end.

parseSearchResponses([], Acc) -> Acc;
parseSearchResponses([X | Rest], Acc) ->
  case parseSearchResponse(X) of
    {ok, FileName, Size} ->
      NewAcc = Acc ++ [{FileName, Size}],
      parseSearchResponses(Rest, NewAcc);
    {ok, _} -> 
      parseSearchResponses(Rest, Acc);
    {error, _} ->
      parseSearchResponses(Rest, Acc)
  end.

%% Parsea las respuestas de búsqueda recibidas en formato SEARCH_RESPONSE
parseSearchResponse(Response) ->
  case string:tokens(Response, " ") of
    ["SEARCH_RESPONSE", _PeerId, FileName, SizeStr] ->
      try
        Size = case SizeStr of
          "-1" -> -1;  % Archivo no encontrado
          _ -> list_to_integer(SizeStr)
        end,
        ?DEBUG_PRINT("[DBG] Me llego: ~p~n", [Response]),
        {ok, FileName, Size}
      catch
        _:_ -> 
          ?DEBUG_PRINT("[DBG] Error parseando size: ~p~n", [SizeStr]),
          {error, invalid_size}
      end;
    Else ->

      ?DEBUG_PRINT("[DBG] Formato de respuesta inválido: ~p~n", [Response]),
      {error, invalid_format}
  end.
