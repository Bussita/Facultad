-module(send).
-include("../dbg/macros.hrl").
-include_lib("kernel/include/file.hrl").
-export([handleDownloadRequest/2, sendSimpleFile/3, sendChunkedFile/3, sendChunksLoop/3]).


%% Manejar solicitud de descarga
handleDownloadRequest(Socket, FileName) ->
  FilePath = filename:join(?SHARED_FOLDER_PATH, FileName),
  
  case file:read_file_info(FilePath) of
    {ok, FileInfo} ->
      FileSize = FileInfo#file_info.size,
      ?DEBUG_PRINT("[DBG ~p] Archivo encontrado: ~p (~p bytes)~n", [self(), FileName, FileSize]),
      % Vemos como enviar el archivo según su tamaño
      if
        FileSize =< ?MAX_FILE_SIZE_FOR_SIMPLE ->
          % Envío simple
          sendSimpleFile(Socket, FilePath, FileSize);
        true ->
          % Envío por chunks
          sendChunkedFile(Socket, FilePath, FileSize)
      end;
      
    {error, _} ->
      ?DEBUG_PRINT("[DBG ~p] Archivo no encontrado: ~p~n", [self(), FileName]),
      gen_tcp:send(Socket, <<112>>) % Código NOTFOUND
  end.


%% Envío simple para archivos pequeños
sendSimpleFile(Socket, FilePath, FileSize) ->
  ?DEBUG_PRINT("[DBG ~p] Enviando archivo simple: ~p (~p bytes)~n", [self(), FilePath, FileSize]),
      
  % Leer y enviar archivo completo
  case file:read_file(FilePath) of
    {ok, FileData} ->
      Packet = <<101, FileSize:32/big, FileData/binary>>, % Código OK + tamaño del archivo + datos
      ?DEBUG_PRINT("[DBG ~p] Enviando archivo completo de ~p bytes~n", [self(), byte_size(FileData)]),
      gen_tcp:send(Socket, Packet),
      ?DEBUG_PRINT("[DBG ~p] Archivo enviado completamente~n", [self()]);
    {error, Reason} ->
      ?DEBUG_PRINT("[DBG ~p] Error leyendo archivo (simple): ~p~n", [self(), Reason])
  end.


%% Envío por chunks para archivos grandes
sendChunkedFile(Socket, FilePath, FileSize) ->
  ?DEBUG_PRINT("[DBG ~p] Enviando archivo por chunks: ~p (~p bytes)~n", [self(), FilePath, FileSize]),
  
  % Enviar: código OK + tamaño del archivo + tamaño del chunk
  Packet = <<101, FileSize:32/big, ?CHUNK_SIZE:32/big>>,
  gen_tcp:send(Socket, Packet),
  
  % Abrir archivo y enviar chunks
  case file:open(FilePath, [read, binary]) of
    {ok, File} ->
      sendChunksLoop(Socket, File, 0),
      file:close(File);
    {error, Reason} ->
      ?DEBUG_PRINT("[DBG ~p] Error abriendo archivo de lectura (chunked): ~p~n", [self(), Reason])
  end.


%% Loop para enviar chunks
sendChunksLoop(Socket, File, ChunkIndex) ->
  case file:read(File, ?CHUNK_SIZE) of
    {ok, ChunkData} -> %% el data es un binary
      ChunkSize = byte_size(ChunkData),
      ?DEBUG_PRINT("[DBG ~p] Enviando chunk ~p (~p bytes)~n", [self(), ChunkIndex, ChunkSize]),
      
      Packet = <<111, ChunkIndex:16/big, ChunkSize:32/big, ChunkData/binary>>,
      % Enviar: código CHUNK + índice + tamaño + datos
      gen_tcp:send(Socket, Packet),
      ?DEBUG_PRINT("[DBG ~p] Chunk ~p enviado~n", [self(), ChunkIndex]),
      
      sendChunksLoop(Socket, File, ChunkIndex + 1);
    eof ->
      ?DEBUG_PRINT("[DBG ~p] Envío de chunks completado~n", [self()]),
      ok;
    {error, Reason} ->
      ?DEBUG_PRINT("[DBG ~p] Error leyendo chunk: ~p~n", [self(), Reason])
  end.