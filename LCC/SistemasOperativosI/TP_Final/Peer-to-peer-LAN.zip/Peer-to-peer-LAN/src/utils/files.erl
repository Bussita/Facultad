-module(files).
-include("../dbg/macros.hrl").
-include_lib("kernel/include/file.hrl").
-export([list/1, searchLocalFiles/2]).

%% Lista los archivos de un directorio específico
list(Route) ->
  case file:list_dir(Route) of 
    {ok, Files} -> {ok, Files};
    {error, Reason} -> 
      {error, Reason}
  end.


%% Obtiene información detallada (tamaño) de un archivo específico
getFileInfo(FileName) ->
  FilePath = filename:join(?SHARED_FOLDER_PATH, FileName),
  case file:read_file_info(FilePath) of
    {ok, FileInfo} ->
      {found, FileName, FileInfo#file_info.size};
    {error, _} ->
      {found, FileName, -1}
  end.

    
%% Busca archivos locales que coincidan con el patrón de búsqueda
searchLocalFiles(Files, Pattern) ->
  LowerPattern = string:to_lower(Pattern),
  case has_wildcard(Pattern) of
    true ->
      FullPattern = filename:join(?SHARED_FOLDER_PATH, Pattern),
      MatchedPaths = filelib:wildcard(FullPattern),
      MatchedFiles = lists:map(fun filename:basename/1, MatchedPaths),
      % Obtener info de cada archivo
      Results = lists:map(getFileInfo, MatchedFiles),
      case Results of
        [] -> [{notFound, Pattern, -1}];
        _ -> Results
      end;

    false ->
      % Buscar coincidencia exacta (case insensitive)
      ExactMatch = lists:filter(
        fun(FileName) ->
          string:to_lower(FileName) =:= LowerPattern
        end,
        Files
      ),
      case ExactMatch of
        [] -> [{notFound, Pattern, -1}];
        Matches ->
          lists:map(getFileInfo, Matches)
      end
  end.

%% Detecta si un patrón contiene caracteres wildcard
has_wildcard(Pattern) ->
  lists:any(fun(C) -> lists:member(C, ".*?[]") end, Pattern).
