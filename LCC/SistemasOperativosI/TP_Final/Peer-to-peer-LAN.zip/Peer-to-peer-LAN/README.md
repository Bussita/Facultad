## Code Style Guide – Erlang

A continuación, se detallan las reglas de formateo del codigo que se siguieron para este proyecto: 

- Indentación de 2 espacios.
- Separación entre funciones de 2 lineas.
- Nombre de los módulos y las funciones en inglés con camelCase.
- Nombre de las variables en inglés con camelCase (y la primera letra en máyuscula, lógicamente).
- Contenido de los `io:format` y `?DEBUG_PRINT` en español.
- Macros en máyusculas.
- Al menos una linea de comentarios previa a cada función, explicando brevemente su funcionamiento.


## Grafos informativos del proyecto

Los siguientes grafos de llamadas (_call graphs_) son a modo de visualización y entendimiento sobre el funcionamiento del programa:

* El siguiente grafo muestra todas las funciones del proyecto, donde los actores coloreados con verde indican que dicho actor se ejecuta constantemente durante todo el programa (nuestro programa debe encargarse de cerrar dichos actores cuando se ejecute `stop` en la CLI):

![Grafo con actores persistentes coloreados](assets/P2P_graph.png)

* El siguiente grafo muestra todas las funciones del proyecto, donde cada actor esta coloreado segun el módulo al que pertenecen:

![Grafo con actores coloreados por modulo](assets/P2P_graph_modules.png)

* El siguiente grafo muestra todas las funciones del proyecto, donde una arista dirigida de color rojo indica que dicha función manda un mensaje mediante el operador (!), y el mismo es recibido con un `receive` activo (sirve para visualizar la comunicación entre procesos):

![Grafo con aristas de comunicacion entre actores](assets/P2P_graph_messages.png)

### Como compilar

Para compilar, tenemos un archivo `makefile` que hace todo el trabajo. Puede consultar todos sus modos de compilación con `make help`

- `make deploy` compila todos los archivos en modo despliegue (o modo estándar). Todos los `.beam` van a la carpeta `src\ebin`.
- `make debug` compila todo en modo de debugueo (+ prints auxiliares por función, muestra todo lo que se recibe por sockets). Todos los `.beam` van a la carpeta `src\ebin_dbg`.
- `make clean` borra todo los archivos `.beam` de las carpetas `src\ebin` y `src\ebin_dbg`.

### Como ejecutar

1. Compilar con alguna de las opciones del `makefile`. Esto hará la compilación de los archivos y además abrirá la consola de Erlang automáticamente.
2. Ejecutar `client:start().` (esta es la función que da inicio a todo el programa).

### Comandos de la CLI 

Una vez corriendo el programa, se mostrará un `?>` en la consola que indica que se está esperando un comando en la CLI del P2P. Para consultar todos los comandos, escriba `help`. Los comandos son:

- `getid` muestra el ID del peer.
- `listar/listar_mis_archivos` listan todos los archivos compartidos del peer.
- `listar_peers` lista todos los nodos conocidos por el peer.
- `encontrar <nombre>` busca un archivo en la carpeta de archivos compartidos. Nótese que debe ser el nombre completo con su extensión (por ejemplo, `find imagen.jpg`).
- `buscar <nombre>` busca un archivo con nombre `<nombre>` en todos los nodos conocidos por el peer. El nombre puede llevar wildcards (ejemplo, `buscar img*`, `buscar *.jpg`, etc) o ser el nombre completo con la extensión del archivo (ejemplo, `buscar imagen.jpg`).
- `descargar <nombre> <ID>` descarga el archivo con nombre `<nombre>` del peer con ID `<ID>`. 
- `help` muestra todos los comandos disponibles.


### Configuraciones

#### Macros

Todas las macros usadas se encuentran en `src\dbg\macros.hrl` y pueden ser allí mismo modificadas: 

- `TCP_PORT` es el puerto TCP usado en todo el programa.
- `UDP_PORT` es el puerto UDP usado en todo el programa.
- `CHUNK_SIZE` es el tamaño de un chunk
- `MAX_FILE_SIZE_FOR_SIMPLE` es el tamaño máximo de un archivo que se manda de manera inmediata.
- `DOWNLOADS_FOLDER_PATH` es el path de la carpeta donde se alojarán las descargas que haga el peer.
- `SHARED_FOLDER_PATH` es el path de la carpeta donde se alojarán los archivos compartidos del peer.
- `DEBUG_PRINT` es una macro para los prints de debug (sólo se ejecutan cuando se compila con `make debug`, en otro caso se ignoran).


### IDs 

El ID que se asigna a un peer al querer conectarse a la red P2P no admite una configuración explícita, pues se elige aleatoriamente, se chequea su unicidad en la red y se lo utiliza en caso de ser único, y de no serlo, se repite el proceso. 

### Directorios

La ubicación de las carpetas de descargas y compartidos es modificable a gusto del usuario dentro del archivo de macros. Simplemente debe modificarse la direccion default (`\downloads` y `\sharedFiles`) por otra.

