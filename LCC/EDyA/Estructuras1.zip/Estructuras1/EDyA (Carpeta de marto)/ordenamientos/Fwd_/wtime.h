#pragma once
double wtime(void);
