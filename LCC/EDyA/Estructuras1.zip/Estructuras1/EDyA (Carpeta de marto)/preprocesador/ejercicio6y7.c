#include <stdio.h>

#define PRINT(string) printf("%s\n",string)

#define PRINTARRAY(array, size) for (int i = 0 ; i < size ; printf("%d\n",arreglo[i++]))

