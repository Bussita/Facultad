#ifndef __MATRIZ_H__
#define __MATRIZ_H__
typedef struct Matriz_ Matriz;

Matriz *matriz_crear(size_t filas, size_t columnas);



#endif