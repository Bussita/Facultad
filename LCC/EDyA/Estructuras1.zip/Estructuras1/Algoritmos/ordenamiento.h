#ifndef __ORDENAMIENTO_H__
#define __ORDENAMIENTO_H__

long binsearch(long[], long len, long value);

long binsearchR(long arr[], long, long, long);

void insertionSort(int[], int);

int* mergeSort(int* arr, int largo);

void quickSort(int* arr, int n);
#endif